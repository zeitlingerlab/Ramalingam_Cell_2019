package au.edu.uq.imb.memesuite.servlet.util;

public interface FeedbackHandler {
  public void whine(String message);
}
