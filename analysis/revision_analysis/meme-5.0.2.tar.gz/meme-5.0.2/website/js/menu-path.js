var menu_is_server = true;
var menu_path_prefix = "../";
if (typeof MemeMenu !== "undefined") MemeMenu.script_loaded();
